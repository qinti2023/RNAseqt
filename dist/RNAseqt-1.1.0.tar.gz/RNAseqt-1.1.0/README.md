# Snakemake workflow

This package helps you generate Snakemake workflow files and folders.

## Installation

Install the package using pip:

```bash
pip install RNAseqt
```

## Usage

Run the command to initialize a project:

```bash
RNAseqt /path/to/project
```
